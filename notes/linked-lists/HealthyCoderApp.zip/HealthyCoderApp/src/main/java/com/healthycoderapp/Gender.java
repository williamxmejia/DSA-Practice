package com.healthycoderapp;

public enum Gender {
	MALE, FEMALE
}
